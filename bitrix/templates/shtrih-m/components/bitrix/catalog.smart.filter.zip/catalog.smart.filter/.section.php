<?
$sSectionName="catalog.smart.filter";
?>