<?
$sSectionName="catalog.section";
?>