<?
$MESS["CATALOG_BUY"] = "Купити";
$MESS["CATALOG_ADD"] = "До кошику";
$MESS["CATALOG_NOT_AVAILABLE"] = "(немає на складі)";
$MESS["CATALOG_TITLE"] = "Найменування";
$MESS["CT_BCS_ELEMENT_DELETE_CONFIRM"] = "Буде видалена вся інформація, що пов'язана з цим записом. Продовжити?";
?>