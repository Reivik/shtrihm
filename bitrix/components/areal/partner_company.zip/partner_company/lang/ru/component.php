<?
$MESS["NO_REQUIRED_FIELD_NAME"] = "Не заполнено обязательно поле &laquo;Название компании&raquo;";
$MESS["NO_REQUIRED_FIELD_DIRECTION"] = "Не заполнено обязательно поле &laquo;Направление&raquo;";
$MESS["NO_REQUIRED_FIELD_PREVIEW_TEXT"] = "Не заполнено обязательно поле &laquo;О компании (кратко)&raquo;";
$MESS["NO_REQUIRED_FIELD_DETAIL_TEXT"] = "Не заполнено обязательно поле &laquo;О компании (подробно)&raquo;";
$MESS["NO_REQUIRED_FIELD_STATUS"] = "Не заполнено обязательно поле &laquo;Статус&raquo;";
$MESS["NO_REQUIRED_FIELD_REGION"] = "Не заполнено обязательно поле &laquo;Регион&raquo;";
$MESS["NO_REQUIRED_FIELD_TOWN"] = "Не заполнено обязательно поле &laquo;Город&raquo;";
$MESS["NO_REQUIRED_FIELD_ADDRESS"] = "Не заполнено обязательно поле &laquo;Адрес(без города)&raquo;";
$MESS["NO_REQUIRED_FIELD_PHONE_EMAIL"] = "Необходимо заполнить поле &laquo;Телефон&raquo; или &laquo;E-mail&raquo;";
$MESS["WRONG_FIELD_EMAIL"] = "Поле &laquo;E-mail&raquo; заполнено неверно.";
$MESS["NO_REQUIRED_FILIAL_FIELD_STATUS"] = "Во всех филиалах должно быть заполнено поле &laquo;Статус&raquo;.";
$MESS["NO_REQUIRED_FILIAL_FIELD_REGION"] = "Во всех филиалах должно быть заполнено поле &laquo;Регион&raquo;.";
$MESS["NO_REQUIRED_FILIAL_FIELD_TOWN"] = "Во всех филиалах должно быть заполнено поле &laquo;Город&raquo;.";
$MESS["NO_REQUIRED_FILIAL_FIELD_ADDRESS"] = "Во всех филиалах должно быть заполнено поле &laquo;Адрес(без города)&raquo;.";
$MESS["NO_REQUIRED_FILIAL_FIELD_PHONE_EMAIL"] = "Необходимо заполнить поле &laquo;Телефон&raquo; или &laquo;E-mail&raquo; во всех филиалах.";
$MESS["NOT_AUTH_USER"] = "Чтобы получить доступ в данный раздел необходимо авторизоваться в системе.";
$MESS["NOT_USER_ACCESS"] = "Недостаточно прав для просмотра данной страницы.";
$MESS["LONG_FIELD_PREVIEW_TEXT"] = "В поле &laquo;О компании (кратко, не более 200 символов)&raquo; введено больше 200 символов.";
$MESS["NOT_FILTER"] = "Необходимо выбрать компанию, для которой просматриваете данные.";
$MESS["NO_COMPANY"] = "Данных о компании не найдено";
?>