<?
$MESS["NOT_AUTH_USER"] = "To get access to this section it is necessary to authorize in the system.";
$MESS["NOT_USER_ACCESS"] = "Not enough rights to view this page.";
?>